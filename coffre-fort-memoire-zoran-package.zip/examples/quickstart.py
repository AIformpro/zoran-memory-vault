from zmem.core import *
print("OK")
