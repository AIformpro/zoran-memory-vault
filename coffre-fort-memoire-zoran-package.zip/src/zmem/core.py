class ZoranMemoryVault:
    def __init__(self):
        self.store = {}
    def put(self, key, value):
        self.store[key] = value
        return "OK"
    def get(self, key, default=None):
        return self.store.get(key, default)
