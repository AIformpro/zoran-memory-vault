from zmem.core import ZoranMemoryVault
def test_put_get():
    v = ZoranMemoryVault()
    v.put("k","v")
    assert v.get("k") == "v"
